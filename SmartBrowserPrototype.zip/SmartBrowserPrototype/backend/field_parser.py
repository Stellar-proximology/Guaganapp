import json
import re
from dataclasses import dataclass, asdict

@dataclass
class FieldVector:
    operator: str
    scale: str
    degree: str = None
    minute: str = None
    second: str = None
    axis: str = None
    raw: str = ""

    def as_dict(self):
        return asdict(self)

class DimensionalParser:
    def __init__(self, path="ontology.json"):
        with open(path, 'r', encoding='utf-8') as f:
            self.ontology = json.load(f)
        self.op_map = {v["dimensional_phrase"].lower(): k for k,v in self.ontology["operator_classes"].items()}
        self.op_map.update({v["parser_operator"].lower(): k for k,v in self.ontology["operator_classes"].items()})
        self.scale_map = {k.lower(): k for k in self.ontology["scale_classes"]}

    def _match_first(self, text, mapping):
        for key, val in mapping.items():
            if key in text:
                return val
        return None

    def parse(self, sentence: str) -> FieldVector:
        lower = sentence.lower()
        op = self._match_first(lower, self.op_map) or "UnknownOperator"
        scale = self._match_first(lower, self.scale_map) or "meso"
        degree = re.search(r"gate\s?(\d+)", lower)
        minute = re.search(r"line\s?(\d+)", lower)
        second = re.search(r"tone\s?(\d+)", lower)
        axis = re.search(r"axis\s?(\w+)", lower)
        return FieldVector(op, scale,
            degree.group(1) if degree else None,
            minute.group(1) if minute else None,
            second.group(1) if second else None,
            axis.group(1) if axis else None,
            raw=sentence)