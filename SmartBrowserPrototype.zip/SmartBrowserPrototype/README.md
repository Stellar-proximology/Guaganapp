# Smart Browser Prototype

## Run the App
1. `pip install -r requirements.txt`
2. `python backend/app.py`
3. Open `frontend/index.html` in your browser

Type natural language in the input. Output will show parsed FieldVector.

---
This is a minimal prototype. Expand as needed!