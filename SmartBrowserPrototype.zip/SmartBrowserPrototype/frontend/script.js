function sendCommand() {
  const input = document.getElementById('commandInput').value;
  fetch('/parse', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ text: input })
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById('output').textContent = JSON.stringify(data, null, 2);
  });
}