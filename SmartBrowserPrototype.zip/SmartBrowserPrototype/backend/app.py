from flask import Flask, request, jsonify
from field_parser import DimensionalParser

app = Flask(__name__)
parser = DimensionalParser("backend/ontology.json")

@app.route('/parse', methods=['POST'])
def parse():
    data = request.get_json()
    sentence = data.get("text", "")
    fv = parser.parse(sentence)
    return jsonify(fv.as_dict())

if __name__ == '__main__':
    app.run(debug=True)